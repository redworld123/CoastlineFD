# Recommended directory form

- FD
  - density
    - *.shp
  - fishnet
    - *.shp
  - *.r
